FactoryGirl.define do
  factory :executive do
    
  end
end
