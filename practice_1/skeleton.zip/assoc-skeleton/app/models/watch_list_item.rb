class WatchListItem < ApplicationRecord
end
