FactoryGirl.define do
  factory :price do
    
  end
end
